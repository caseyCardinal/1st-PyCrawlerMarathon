# -*- coding: utf-8 -*-
import scrapy
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from pprint import pprint

def pptTitleInfo(pptURL, tlTxt):
    try:
        newR=requests.get(pptURL)
        newSoup = BeautifulSoup(newR.text, "lxml")
        rult=newSoup.find_all(class_='article-meta-value')
        author=rult[0].text
        edtTm=rult[3].text
        print(tlTxt, '作者: ' + author, '時間: ' + edtTm)
        # 整理文章資訊 ------------------------------------------------------
        '''
        data = {
        'article_author': author,
        'article_title': title,
        'article_date': edtTm
        }
        yield data
        '''
    except:
       print('new html error')

class PttbsballSpider(scrapy.Spider):
    name = 'PTTBsBall'
    allowed_domains = ['www.ptt.cc']
    start_urls = ['https://www.ptt.cc/bbs/Baseball/index.html']

    cookies = {'over18': '1'}

    
    def parse(self, response):
        objSoup=BeautifulSoup(response.text, 'lxml')
        for d in objSoup.find_all(class_="title"):
            title=d.text.replace('\t', '').replace('\n', '')
            newHTML='https://www.ptt.cc'+d.find('a')['href']
            print(newHTML, title)
            pptTitleInfo(newHTML, title)
            #data = {
            #    'article_title': title
            #}
            #yield data
        